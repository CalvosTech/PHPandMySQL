<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Cadastre-se</title>
    </head>
<body>
<?php
if(!isset($_SESSION)){
    session_start();
}

if(!isset($_SESSION['cod_usuario'])){
    die("Você precisa estar logado<p><a href=\"index.php\">Entrar</a></p>");
} 
?>
</body>
</html>