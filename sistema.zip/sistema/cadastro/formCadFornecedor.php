<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CADASTRO DE FORNECEDOR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="../js/buscaCep.js"> </script>
	<script src="../js/validaCPF.js"> </script>
  </head>
<body>
	<div class="container">
  		<div class="row">
    		<div class="col">
      			
    		</div>
    		<div class="col">
      			<div class="mb-3">
      				<h1 class="bg-primary text-white">Cadastro de Fornecedor</h1>

      				<form action="#" method="POST" enctype="multipart/form-data">
	  					<label class="form-label">Nome:</label>
	  					<input type="text" class="form-control" id="nomeFornecedor" name="nomeFornecedor" required>
	  					<label class="form-label">CNPJ:</label>
	  					<input type="text" class="form-control" id="cnpjFornecedor" name="cnpjFornecedor" required>
	  					<label class="form-label">IE:</label>
	  					<input type="text" class="form-control" id="ieFornecedor" name="ieFornecedor" required>
	  					<label class="form-label">CEP:</label>
	  					<input type="text" class="form-control" id="cep" name="cepFornecedor" onblur="pesquisacep(this.value);" required>
	  					<label class="form-label">Rua:</label>
	  					<input type="text" class="form-control" id="rua" name="ruaFornecedor" required>
	  					<label class="form-label">Bairro:</label>
	  					<input type="text" class="form-control" id="bairro" name="bairroFornecedor" required>
	  					<label class="form-label">Cidade:</label>
	  					<input type="text" class="form-control" id="cidade" name="cidadeFornecedor" required>
	  					<label class="form-label">Estado:</label>
	  					<input type="text" class="form-control" id="uf" name="ufFornecedor" required>
	  					<label class="form-label">Nº:</label>
	  					<input type="text" class="form-control" id="numFornecedor" name="numFornecedor" required>
	  					<label class="form-label">Telefone:</label>
	  					<input type="text" class="form-control" id="telefoneFornecedor" name="telefoneFornecedor" required>
	  					<label class="form-label">Email:</label>
	  					<input type="email" class="form-control" id="emailFornecedor" name="emailFornecedor" required>
						<label class="form-label">Foto:</label>
						<input type="file" class="form-control" name="imgFornecedor" required>  
	  					<br>
	  					<div class="text-center">
	  						<input type="submit" name="Cadastrar" class="btn btn-primary">
	  						<input type="reset" name="Limpar" class="btn btn-danger">
							  <button type="reset" class="btn btn-success" onclick="javascript: location.href='../menu.php'">Voltar</button>
	  					</div>
					</form>
				</div>
    		</div>
    		<div class="col">
      			
    		</div>
  		</div>
	</div>
</body>
</html>


<?php
if(!empty($_POST))
{
	$nome = $_POST['nomeFornecedor'];
	$cnpj = $_POST['cnpjFornecedor'];
	$ie = $_POST['ieFornecedor'];
	$cep = $_POST['cepFornecedor'];
	$num = $_POST['numFornecedor'];
	$telefone = $_POST['telefoneFornecedor'];
	$email = $_POST['emailFornecedor'];
	$imagem = $_FILES['imgFornecedor'];
	$dir = "../img/fornecedor/";

	date_default_timezone_set('America/Sao_Paulo');
	$extensao = strtolower(substr($imagem['name'],-4));
	$novo_nome = date("Y.m.d-H.i.s") . $extensao;
	move_uploaded_file($imagem['tmp_name'], $dir.$novo_nome);
	$caminhoIMG = "img/fornecedor/".$novo_nome;

	include_once('../config/conexao.php');

	try {
	  
	  $stmt = $conn->prepare("INSERT INTO fornecedor (nome, cnpj, ie, cep, numero, telefone, email, imagem) VALUES (:nome, :cnpj, :ie, :cep, :numero, :telefone, :email, :imagem)");

	  $stmt->bindParam(':nome', $nome);
	  $stmt->bindParam(':cnpj', $cnpj);
	  $stmt->bindParam(':ie', $ie);
	  $stmt->bindParam(':cep', $cep);
	  $stmt->bindParam(':numero', $num);
	  $stmt->bindParam(':telefone', $telefone);
	  $stmt->bindParam(':email', $email);
	  $stmt->bindParam(':imagem', $caminhoIMG);
	  
	  $stmt->execute();

	  echo "<script>alert('Cadastrado com Sucesso');</script>";

	} catch(PDOException $e) {
	  echo "Erro ao cadastrar: " . $e->getMessage();
	}
	$conn = null;
}
?>