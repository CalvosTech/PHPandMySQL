<?php

include_once('../../config/conexao.php');

$cod = $_POST['codigo']; 
$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$funcionario = $_POST['funcionario'];

	try 
	{

		$stmt = $conn->prepare("UPDATE usuario SET nome = :nome,
												   email = :email,
												   senha = :senha,
												   funcionario = :funcionario WHERE codigo = :id");

		$stmt->execute(array(':id' => $cod, 
							 ':nome' => $nome,
							 ':email' => $email,
							 ':senha' => $senha,
                             ':funcionario' => $funcionario));
		
		header( "refresh:0;url=../../consulta/consultaUsuario.php" );

		echo "<script>alert('USUARIO ALTERADO COM SUCESSO');</script>";


	} 

	catch(PDOException $e) 

	{

		echo 'Error: ' . $e->getMessage();

	}
 ?>
