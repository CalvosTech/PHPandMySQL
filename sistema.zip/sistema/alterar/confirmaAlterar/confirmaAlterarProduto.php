<?php

include_once('../../config/conexao.php');



$cod = $_POST['codigo']; 
$nome = $_POST['nome'];
$tipo = $_POST['tipo'];
$dataCompra = $_POST['dataCompra'];
$dataVencimento = $_POST['dataVencimento'];
$valorCompra = $_POST['valorCompra'];
$valorVenda = $_POST['valorVenda'];
$fornecedor = $_POST['fornecedor'];

	try 
	{

		$stmt = $conn->prepare("UPDATE produto SET nome = :nome,
												   tipo = :tipo,
												   dataCompra = :dataCompra,
												   dataVencimento = :dataVencimento,
												   valorCompra = :valorCompra,
                                                   valorVenda = :valorVenda,
												   fornecedor = :fornecedor WHERE codigo = :id");

		$stmt->execute(array(':id' => $cod, 
							 ':nome' => $nome,
							 ':tipo' => $tipo,
							 ':dataCompra' => $dataCompra,
							 ':dataVencimento' => $dataVencimento,
							 ':valorCompra' => $valorCompra,
                             ':valorVenda' => $valorVenda,
                             ':fornecedor' => $fornecedor));
		
		header( "refresh:0;url=../../consulta/consultaProduto.php" );

		echo "<script>alert('PRODUTO ALTERADO COM SUCESSO');</script>";


	} 

	catch(PDOException $e) 

	{

		echo 'Error: ' . $e->getMessage();

	}
 ?>
