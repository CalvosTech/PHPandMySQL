<html>
	<head>
		<meta charset="utf-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
		<title>SISTEMA COMERCIAL - ALTERAR PRODUTO</title>
		</script>
	</head>
	<body>

	<?php

		$cod = $_GET['id'];
		
		include_once('../config/conexao.php');
		 
			$select = $conn->prepare("SELECT * FROM usuario where codigo=$cod");
			$select->execute();
		
			$row = $select->fetch();
			
	 ?>
		<form action="confirmaAlterar/confirmaAlterarUsuario.php" method="POST">

			<div class="container">
				<div class="row">
    				<div class="col">
      			
    				</div>
    				<div class="col">
      					<div class="mb-3">
      						<h1 class="bg-primary text-white">Alterar Usuario</h1>
				
							<label for="uCodigo"><b>Codigo</b></label>
							<input type="number" class="form-control" name="codigo" value="<?php echo $row['codigo'];?>" readonly="true">
							
							<label for="uNome"><b>Nome</b></label>
							<input type="text" placeholder="Nome do Usuario" class="form-control" name="nome" value="<?php echo $row['nome'];?>" required>
							
							<label for="uEmail"><b>Email</b></label>
							<input type="email" placeholder="Email do Usuario" class="form-control" name="email" value="<?php echo $row['email'];?>" required>
							
							<label for="uSenha"><b>Senha</b></label>
							<input type="password" placeholder="Senha do Usuario" class="form-control" name="senha" value="<?php echo $row['senha'];?>" required>
							
							<label for="uFuncionario"><b>Funcionario</b></label>
							<input type="number" placeholder="Funcionario" class="form-control" name="funcionario" value="<?php echo $row['funcionario'];?>" required>

							<br>	
							<div class="text-center">
								<button type="submit" class="btn btn-primary">Atualizar</button>
								<button type="reset" class="btn btn-success" onclick="javascript: location.href='../consulta/consultaUsuario.php'">Voltar</button>
							</div>
						</div>
  					</div>
  					<div class="col">
      			
    				</div>
				</div>
			</div>
		</form>
	</body>
</html