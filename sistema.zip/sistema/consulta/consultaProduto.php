<!doctype html>
<html lang=''>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="css/styles.css">
   <link rel="stylesheet" href="css/styless.css">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="script.js"></script>
   <script type="text/javascript" src="js/ajax.js"></script>
   <title>SISTEMA COMERCIAL - CONSULTA PRODUTO</title>
</head>
<body>
	
<?php  
	
	include_once('../config/conexao.php');
	try 
	{	   
		$select = $conn->prepare('SELECT * FROM produto');
		$select->execute();
	  
		while($row = $select->fetch()) 
		{
			echo "<p>";
			echo "<br><img src='../".$row['imagem']."' width= 80px>";
			echo "<br><b>Codigo: </b>".$row['codigo'];
			echo "<br><b>Nome: </b>".$row['nome'];
			echo "<br><b>Tipo: </b>".$row['tipo'];
			echo "<br><b>dataCompra: </b>".$row['dataCompra'];
			echo "<br><b>dataVencimento: </b>".$row['dataVencimento'];
			echo "<br><b>valorCompra: </b>".$row['valorCompra'];
			echo "<br><b>valorVenda: </b>".$row['valorVenda'];
			echo "<br><b>Fornecedor: </b>".$row['fornecedor'];
			echo "<br>";
?>
	<button onclick="window.location.href='../alterar/alterarProduto.php?id=<?php echo $row['codigo'];?>'">
		Alterar
	</button>
	
	<button onclick="window.location.href='../excluir/excluirProduto.php?id=<?php echo $row['codigo'];?>'">
		Excluir
	</button>
	
	<button onclick="window.location.href='../menu.php'">Voltar</button>
	<hr>
<?php
		}
	} 
	catch(PDOException $e) 
	{
		echo 'ERROR: ' . $e->getMessage();
	}
 ?>
	
	</div>
 </body>
<html>