<?php

if(!isset($_SESSION)){
    session_start();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/index.css"/>
</head>
<body>
    <form class= "form" action="loginIndex.php" method="POST" autocomplete="off" >
    <div class="card">
        <div class="card-top">
            <img class="imglogin" src="img/sistema/user.png" alt="">
            <h2 class="titulo">Painel de Controle</h2>
            <p>Gerenciar seu negócio</p>
        </div>
        <div class= "card-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="Digite seu email">
        </div>
        <div class= "card-group">
            <label>Senha</label>
            <input type="password" name="senha" placeholder="Digite sua senha">
        </div>
        <div class= "card-group checkbox">
            <label><input type="checkbox"> Lembre-me</label>
        </div>
        <div class= "card-group btn">
            <button type="submit">ACESSAR</button>
        </div>
        <div class= "card-group btn">
            <p>Cadastre-se aqui!</p>
            <button type="reset" class="btn btn-success" onclick="javascript: location.href='cadastre.php'">CADASTRAR</button>
        </div>
    </div>
</form>
</body>
</html>