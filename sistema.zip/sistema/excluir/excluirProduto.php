<link rel="stylesheet" href="css/styless.css">
<?php

	echo"<h1>Excluir Produto</h1>";

	$cod = $_GET['id'];
	include_once('../config/conexao.php');
		$select = $conn->prepare("SELECT * FROM produto where codigo=$cod");
		$select->execute();
	while($row = $select->fetch()) 
	{
		echo "<p>";
		echo "<br><b>Codigo: </b>".$row['codigo'];
		echo "<br><b>Nome: </b>".$row['nome'];
		echo "<br><b>Data da Compra: </b>".$row['dataCompra'];
		echo "<br><b>Data de Vencimento: </b>".$row['dataVencimento'];
		echo "<br><b>Valor da Compra: </b>".$row['valorCompra'];
		echo "<br><b>Valor da Venda: </b>".$row['valorVenda'];
		echo "<br><b>Fornecedor: </b>".$row['fornecedor'];
		echo "</p>";
		echo "<br><b>Tipo: </b>".$row['tipo'];
?>
	
	<button onclick="window.location.href='confirmaExcluir/confirmaExcluirProduto.php?id=<?php echo $row['codigo'];?>'">
		Excluir
	</button>
	
	<button onclick="window.location.href='../consulta/consultaProduto.php'">Voltar</button>

<?php
		}
?>
