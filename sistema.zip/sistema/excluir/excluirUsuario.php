<link rel="stylesheet" href="css/styless.css">
<?php

	echo"<h1>Excluir Usuario</h1>";

	$cod = $_GET['id'];
	
	include_once('../config/conexao.php');
		$select = $conn->prepare("SELECT * FROM usuario where codigo=$cod");
		$select->execute();
	while($row = $select->fetch()) 
	{
		echo "<p>";
        echo "<br><b>Nome: </b>".$row['nome'];
        echo "<br><b>Email: </b>".$row['email'];
        echo "<br><b>Senha: </b>".$row['senha'];
        echo "<br><b>Funcionario: </b>".$row['funcionario'];
        echo "</p>";
        echo "<br><b>Codigo: </b>".$row['codigo'];
?>
	
	<button onclick="window.location.href='confirmaExcluir/confirmaExcluirUsuario.php?id=<?php echo $row['codigo'];?>'">
		Excluir
	</button>
	
	<button onclick="window.location.href='../consulta/consultaUsuario.php'">Voltar</button>

<?php
		}
?>
