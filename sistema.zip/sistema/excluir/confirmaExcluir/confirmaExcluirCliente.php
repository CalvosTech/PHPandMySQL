<?php

$cod = $_GET['id'];
include_once('../../config/conexao.php');
	try 
	{
		$delete = $conn->prepare("DELETE FROM cliente WHERE codigo=$cod");
		$delete->execute();
		echo "<h1>Cliente excluido com sucesso</h1>";
	} 
	catch(PDOException $e) 
	{
		echo 'ERROR: ' . $e->getMessage();
	}
 ?>
<button onclick="window.location.href='../../consulta/consultaCliente.php'">Voltar</button>