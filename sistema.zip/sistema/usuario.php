<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Usuario</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/user.css"/>
    <script src="main.js"></script>
</head>
<body>
	
	
	<div class="consulta">
	<div class="titulo"><h1>Olá</h1></div>
<div class="card">
<?php
	include_once('config/conexao.php');
	$codigo = $_SESSION['cod_usuario'];

	try 
	{	   
        $sql = "SELECT * FROM usuario WHERE codigo = :codigo";
        $sql = $conn->prepare($sql);
        $sql->bindValue("codigo", $codigo);
		$sql->execute();
	  
		while($row = $sql->fetch()) 
		{
			echo "<div class=\"card-top\">";
			echo "<img class=\"imgUsuario\" src='".$row['imagem']."'>";
			echo "<h2>".$row['nome']."</h2></div>";
			echo "<div class=\"card-mid\"><p><b>Codigo: </b>".$row['codigo']."<p>";
			// echo "<p><b>Nome: </b>".$row['nome']."</p>";
			echo "<p><b>Email: </b>".$row['email']."</p>";
			echo "<p><b>Senha: </b>".$row['senha']."</p>";
			echo "<p><b>Funcionario: </b>".$row['funcionario']."</p>";
		}
	} 
	catch(PDOException $e) 
	{
		echo 'ERROR: ' . $e->getMessage();
	}	
?>
<button class="button" type="reset" onclick="javascript: location.href='menu.php'">VOLTAR</button>
	<?php 
		echo "</div>";
	?>
	</div>
</div>
</body>
</html>