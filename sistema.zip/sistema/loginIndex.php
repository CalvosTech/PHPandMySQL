<?php
if(isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['senha']) && !empty($_POST['senha'])) {
    require 'config/conexao.php';
    require 'usuario.class.php';

    $class = new usuario();
    $email = addslashes($_POST['email']);
    $senha = addslashes($_POST['senha']);

if($class->login($email, $senha) == true){
    if(isset($_SESSION['cod_usuario'])){
        header('location: menu.php');
}else 
    header('location: index.php');

}else 
    header('location: index.php');

}
else {
    header('location: index.php');
}
?>