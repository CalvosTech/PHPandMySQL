<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Cadastre-se</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/index.css"/>
</head>
<body>
    <form class="form" action="#" method="POST" autocomplete="off" enctype="multipart/form-data">
    <div class="card">
        <div class="card-top">
            <img class="imglogin" src="img/sistema/user.png" alt="">
            <h2 class="titulo">Cadastre-se aqui!</h2>
            <p>Gerencie seu negócio</p>
        </div>
        <div class= "card-group">
            <label>Nome</label>
            <input type="text" name="nome" placeholder="Digite seu nome" required>
        </div>
        <div class= "card-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="Digite seu email" required>
        </div>
        <div class= "card-group">
            <label>Senha</label>
            <input type="password" name="senha" placeholder="Digite sua senha" required>
        </div>
        <div class= "card-group">
            <label>Confirme sua senha</label>
            <input type="password" name="confirmaSenha" placeholder="Confirme sua senha" required>
        </div>
        <div class= "card-group">
            <label>Funcionario</label>
            <input type="number" name="funcionario" placeholder="Informe seu número de funcionário" required>
        </div>
        <div class= "card-group">
            <label>Foto de identificação</label>
            <input type="file" name="imgUsuario" required>
        </div>
        <p></p>
        <div class= "card-group btn">
            <button type="submit">CADASTRAR</button>
        </div>
    </div>
</form>
</body>
</html>

<?php
if(!empty($_POST)) {
        $nome = $_POST['nome'];
	    $email = $_POST['email'];
	    $senha = $_POST['senha'];
	    $funcionario = $_POST['funcionario'];
	    $imagem = $_FILES['imgUsuario'];
        $dir = "img/usuario/";

        date_default_timezone_set('America/Sao_Paulo');
        $extensao = strtolower(substr($imagem['name'],-4));
        $novo_nome = date("Y.m.d-H.i.s") . $extensao;
        move_uploaded_file($imagem['tmp_name'], $dir.$novo_nome);
        $caminhoIMG = "img/usuario/".$novo_nome;

include_once('config/conexao.php');
$sql = "SELECT codigo FROM usuario WHERE email = :email";
$sql = $conn->prepare($sql);
    $sql->bindValue("email", $email);
    $sql->execute(); 

    if($sql->rowCount() != 0){
        echo "<script>alert('Este e-mail já está cadastrado');</script>";
}else {

if($_POST['senha'] !== $_POST['confirmaSenha']) {
    echo "<script>alert('Senhas diferentes');</script>";

}else {
    try {
        $stmt = $conn->prepare("INSERT INTO usuario (nome, email, senha, funcionario, imagem) VALUES (:nome, :email, :senha, :funcionario, :imagem)");
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':senha', $senha);
        $stmt->bindParam(':funcionario', $funcionario);
        $stmt->bindParam(':imagem', $caminhoIMG);
        $stmt->execute();

    header('location: index.php');

	} catch(PDOException $e) {
	  echo "Erro ao cadastrar: " . $e->getMessage();
    }
}
}
$conn = null;
}
?>